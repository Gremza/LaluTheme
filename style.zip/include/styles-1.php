<!--- Header right --->
<style> header{
    background:<?php  echo  get_theme_mod( 'gr_header_background_settings', '#000' );?>;
}
@media (min-width:601px)  {  
 
.navbar-nav>li:first-child {
    margin: 0 0 0 -40px;
} 
.navbar-nav{float:left;}
.top{padding-top: 5px;}
}
 .searchbar{float:right;}
</style>