<?php
 
 
get_header(); ?> 
<div   class="container     ">
	 
 
	<p><?php _e('Sorry, this page does not exist.','gremza_university'); ?></p>
 
	</div>
<?php get_footer(); ?>